To run, the project, you first have to open the CatanServer.py file through Terminal or Command Prompt. Then, open up four additional
Terminal or Command Prompt windows, and in each of them, open up the CatanClient.py file. You will need to press space to roll the dice
when you start off your turn, but apart from that, the game itself is self-explanatory. There are no additional libraries that need
to be installed, only Python is needed.